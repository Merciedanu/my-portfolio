import React, { useState, useEffect } from 'react';
import { 
  INITIAL_HERO_INFO,
  INITIAL_PROJECTS,
  INITIAL_CERTIFICATIONS,
  INITIAL_MESSAGES,
  loadHeroInfo, 
  loadProjects,
  loadCertifications,
  loadMessages,
} from './data';
import { HeroInfo, Project, Certification, Message } from './types';

// Admin Viewport Components
import PublicPortfolio from './components/PublicPortfolio';
import CmsLogin from './components/CmsLogin';
import CmsSidebar, { CmsView } from './components/CmsSidebar';
import CmsDashboard from './components/CmsDashboard';
import CmsProjects from './components/CmsProjects';
import CmsHeroAbout from './components/CmsHeroAbout';
import CmsCertifications from './components/CmsCertifications';
import CmsMessages from './components/CmsMessages';
import CmsSettings from './components/CmsSettings';

// Firebase Services integration
import {
  subscribeToAuth,
  signOutAdmin,
  getHeroInfo as fetchHeroInfoFromFirebase,
  saveHeroInfo as saveHeroInfoInFirebase,
  getProjects as fetchProjectsFromFirebase,
  saveProject,
  deleteProject,
  getCertifications as fetchCertificationsFromFirebase,
  saveCertification,
  deleteCertification,
  getMessages as fetchMessagesFromFirebase,
  saveMessage,
  deleteMessage
} from './firebaseService';

export default function App() {
  // Navigation State
  const [currentRoute, setCurrentRoute] = useState<'public' | 'login' | 'cms'>('public');
  const [cmsView, setCmsView] = useState<CmsView>('dashboard');
  const [isFirebaseLoaded, setIsFirebaseLoaded] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Applet Data Persistence
  const [heroInfo, setHeroInfo] = useState<HeroInfo>(() => loadHeroInfo());
  const [projects, setProjects] = useState<Project[]>(() => loadProjects());
  const [certifications, setCertifications] = useState<Certification[]>(() => loadCertifications());
  const [messages, setMessages] = useState<Message[]>(() => loadMessages());

  // Web Browser Title Dynamic Synchronization
  const [appTitle, setAppTitle] = useState('Mercy Ndanu Portfolio');
  const [appDescription, setAppDescription] = useState('Senior Systems Architect Portfolio Site');

  // Interactive Trigger: Create draft project immediately
  const [openCreateImmediately, setOpenCreateImmediately] = useState(false);

  // Synchronize Browser Title
  useEffect(() => {
    document.title = appTitle;
  }, [appTitle]);

  // Initial Sync containing Auth and Firestore data pulling
  useEffect(() => {
    // Setup Auth listener
    const unsubscribe = subscribeToAuth((user) => {
      if (user) {
        setIsAdmin(true);
        setCurrentRoute((prev) => (prev === 'login' ? 'cms' : prev));
      } else {
        setIsAdmin(false);
        // Only kick out to public if they were previously in the cms
        setCurrentRoute((prev) => (prev === 'cms' ? 'public' : prev));
      }
    });

    // Pull from Cloud Firestore Database
    const loadCloudData = async () => {
      try {
        const cloudHero = await fetchHeroInfoFromFirebase();
        setHeroInfo(cloudHero);

        const cloudProjects = await fetchProjectsFromFirebase();
        setProjects(cloudProjects);

        const cloudCertifications = await fetchCertificationsFromFirebase();
        setCertifications(cloudCertifications);

        const cloudMessages = await fetchMessagesFromFirebase();
        setMessages(cloudMessages);
        
        setIsFirebaseLoaded(true);
      } catch (err) {
        console.error("Failed to fetch Firestore attributes during sync: ", err);
        setIsFirebaseLoaded(true);
      }
    };

    loadCloudData();

    return () => unsubscribe();
  }, []);

  // Public Form message dispatch connector
  const handleSendMessage = async (name: string, email: string, subject: string, messageBody: string) => {
    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      name,
      email,
      subject,
      message: messageBody,
      timestamp: new Date().toISOString(),
      isRead: false
    };

    const updated = [newMessage, ...messages];
    setMessages(updated);
    
    try {
      await saveMessage(newMessage);
    } catch (e) {
      console.error("Failed syncing message to Firestore: ", e);
    }
  };

  // State Updates
  const handleSaveHeroInfo = async (newInfo: HeroInfo) => {
    setHeroInfo(newInfo);
    try {
      await saveHeroInfoInFirebase(newInfo);
    } catch (e) {
      console.error("Failed syncing hero_info to Firestore: ", e);
    }
  };

  const handleSaveProjects = async (newProjects: Project[]) => {
    const backup = [...projects];
    setProjects(newProjects);

    try {
      // Find deleted ones
      const deleted = backup.filter(p => !newProjects.some(np => np.id === p.id));
      for (const p of deleted) {
        await deleteProject(p.id);
      }
      // Save or update existing/new ones
      for (const p of newProjects) {
        await saveProject(p);
      }
    } catch (e) {
      console.error("Failed syncing projects to Firestore: ", e);
    }
  };

  const handleSaveCertifications = async (newCerts: Certification[]) => {
    const backup = [...certifications];
    setCertifications(newCerts);

    try {
      const deleted = backup.filter(c => !newCerts.some(nc => nc.id === c.id));
      for (const c of deleted) {
        await deleteCertification(c.id);
      }
      for (const c of newCerts) {
        await saveCertification(c);
      }
    } catch (e) {
      console.error("Failed syncing certifications to Firestore: ", e);
    }
  };

  const handleSaveMessages = async (updatedMessages: Message[]) => {
    const backup = [...messages];
    setMessages(updatedMessages);

    try {
      const deleted = backup.filter(m => !updatedMessages.some(nm => nm.id === m.id));
      for (const m of deleted) {
        await deleteMessage(m.id);
      }
      for (const m of updatedMessages) {
        await saveMessage(m);
      }
    } catch (e) {
      console.error("Failed syncing messages to Firestore: ", e);
    }
  };

  // Sidebar Trigger: Initiate Project slot
  const handleAddNewProjectFromSidebar = () => {
    setOpenCreateImmediately(true);
    setCmsView('projects');
  };

  // View state override
  const handleCmsNavigateAndClear = (view: CmsView) => {
    if (view !== 'projects') {
      setOpenCreateImmediately(false);
    }
    setCmsView(view);
  };

  // Factory seeding reset
  const handleResetFactoryData = async () => {
    setHeroInfo(INITIAL_HERO_INFO);
    setProjects(INITIAL_PROJECTS);
    setCertifications(INITIAL_CERTIFICATIONS);
    setMessages(INITIAL_MESSAGES);
    setAppTitle('Mercy Ndanu Portfolio');

    try {
      await saveHeroInfoInFirebase(INITIAL_HERO_INFO);
      
      // Wipe projects
      for (const p of projects) {
        await deleteProject(p.id);
      }
      for (const p of INITIAL_PROJECTS) {
        await saveProject(p);
      }

      // Wipe certs
      for (const c of certifications) {
        await deleteCertification(c.id);
      }
      for (const c of INITIAL_CERTIFICATIONS) {
        await saveCertification(c);
      }

      // Wipe messages
      for (const m of messages) {
        await deleteMessage(m.id);
      }
      for (const m of INITIAL_MESSAGES) {
        await saveMessage(m);
      }
    } catch (e) {
      console.error("Failed factory database sync reset: ", e);
    }
  };

  // Navigation route logic mapping
  if (currentRoute === 'public') {
    return (
      <PublicPortfolio 
        heroInfo={heroInfo}
        projects={projects}
        certifications={certifications}
        onNavigateToLogin={() => setCurrentRoute('login')}
        onSendMessage={handleSendMessage}
        isAdmin={isAdmin}
      />
    );
  }

  if (currentRoute === 'login') {
    return (
      <CmsLogin 
        onBackToPublic={() => setCurrentRoute('public')}
        onLoginSuccess={() => {
          setCurrentRoute('cms');
          setCmsView('dashboard');
        }}
      />
    );
  }

  // Master Administration Frame Layout
  const unreadCount = messages.filter(m => !m.isRead).length;

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      
      {/* 1. Left reusable Admin sidebar */}
      <CmsSidebar 
        currentView={cmsView}
        onViewChange={handleCmsNavigateAndClear}
        onLogout={signOutAdmin}
        onAddNewProject={handleAddNewProjectFromSidebar}
        unreadCount={unreadCount}
        profilePhoto={heroInfo.profilePhoto}
        adminName={heroInfo.fullName}
      />

      {/* 2. Main Workspace Dynamic Router Screen */}
      <div className="flex-1 flex flex-col min-w-0 h-full relative">
        {cmsView === 'dashboard' && (
          <CmsDashboard 
            projects={projects}
            messages={messages}
            certifications={certifications}
            onNavigateToView={handleCmsNavigateAndClear}
            onAddNewProject={handleAddNewProjectFromSidebar}
            onLogout={signOutAdmin}
            onReturnToPublic={() => setCurrentRoute('public')}
          />
        )}

        {cmsView === 'hero-about' && (
          <CmsHeroAbout 
            heroInfo={heroInfo}
            onSaveHeroInfo={handleSaveHeroInfo}
            onCancel={() => setCmsView('dashboard')}
          />
        )}

        {cmsView === 'projects' && (
          <CmsProjects 
            projects={projects}
            onSaveProjects={handleSaveProjects}
            openCreateImmediately={openCreateImmediately}
          />
        )}

        {cmsView === 'certifications' && (
          <CmsCertifications 
            certifications={certifications}
            onSaveCertifications={handleSaveCertifications}
          />
        )}

        {cmsView === 'messages' && (
          <CmsMessages 
            messages={messages}
            onSaveMessages={handleSaveMessages}
          />
        )}

        {cmsView === 'settings' && (
          <CmsSettings 
            onResetFactoryData={handleResetFactoryData}
            appTitle={appTitle}
            onUpdateTitle={setAppTitle}
            appDescription={appDescription}
            onUpdateDescription={setAppDescription}
          />
        )}
      </div>

    </div>
  );
}
