import { initializeApp } from 'firebase/app';
import { initializeFirestore, doc, getDocFromServer } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyBtVe7ajKZTpUBF-P-qr6UnMw8Tk0uKFPY",
  authDomain: "learned-vehicle-492012-a1.firebaseapp.com",
  projectId: "learned-vehicle-492012-a1",
  storageBucket: "learned-vehicle-492012-a1.firebasestorage.app",
  messagingSenderId: "976314087766",
  appId: "1:976314087766:web:dd37bf2252574f0903fef7"
};

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize Firestore with the exact custom databaseId from configuration
export const db = initializeFirestore(app, {}, "ai-studio-6a4231bd-e012-45b9-937f-375e624980de");

// Initialize Authentication
export const auth = getAuth(app);

// Connectivity check as requested in Firebase specification skill
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Firebase connection initialized successfully.");
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Please check your Firebase configuration or network status. Core client appears offline.");
    } else {
      // In private sandboxes a direct read to an unprovisioned test document is allowed to fail with Permission Denied;
      // getting any response or permission error actually confirms network and authentication parameters are fully active.
      console.log("Firebase connection handshake processed.");
    }
  }
}
testConnection();
